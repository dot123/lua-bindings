
cc.FileUtils:getInstance():setPopupNotify(false)

require "config"
require "cocos.init"

local function main()
    -- require("app.MyApp"):create():run()
    local hello = HelloWorld:create()
    local sceneGame = cc.Scene:create()
    sceneGame:addChild(hello)
    cc.Director:getInstance():runWithScene(sceneGame)
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    print(msg)
end
